import logo from './logo.svg';
import './App.css';
import Message from './Message';

function App() {
  return (
    <div className="App">
      <Message message = {'первый семинар по React'} />
    </div>
  );
}

export default App;
